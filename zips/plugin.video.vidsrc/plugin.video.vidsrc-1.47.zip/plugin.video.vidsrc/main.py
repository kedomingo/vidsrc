import math
import sys
import xbmc
import xbmcgui
import xbmcplugin
import requests
from urllib.parse import parse_qs
from urllib.parse import urlencode
from urllib.parse import quote
from resolver import vidsrc
import json

BASE_URL = "https://api.themoviedb.org/3"
THUMB_BASE_URL = "https://image.tmdb.org/t/p/w185"
IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500"
API_KEY = "d75677fb857aa6f339c67d9ba89f9aed"  # DO NOT COMMIT

ADDON_HANDLE = int(sys.argv[1])


def show_notification(title, message):
  # Create a dialog box with a title and message
  xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, 5000)


def build_url(query):
  return f"{sys.argv[0]}?{urlencode(query)}"


def get_json(url):
  response = requests.get(url)
  response.raise_for_status()
  return response.json()


def main_menu():
  xbmcplugin.setContent(handle=ADDON_HANDLE, content='videos')

  # Add Trending option
  url = build_url({'action': 'trending', 'page': 1})
  xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, xbmcgui.ListItem('Trending'),
                              True)

  # Add Genre option
  url = build_url({'action': 'genres'})
  xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, xbmcgui.ListItem('Genre'),
                              True)

  # Add Find option
  url = build_url({'action': 'find'})
  xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, xbmcgui.ListItem('Find'), True)

  xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_trending(page):
  url = f"{BASE_URL}/trending/movie/day?api_key={API_KEY}&page={page}"
  data = get_json(url)

  __previous_pages(page, {'action': 'trending'})

  for movie in data['results']:
    __list_movie(movie)

  __next_pages(page, data['total_pages'], {'action': 'trending'})

  xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_genres():
  url = f"{BASE_URL}/genre/movie/list?api_key={API_KEY}"
  data = get_json(url)

  for genre in data['genres']:
    url = build_url({'action': 'movies_by_genre', 'genre_id': genre['id'],
                     'genre_name': genre['name'], 'page': 1})
    list_item = xbmcgui.ListItem(genre['name'])
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, True)

  xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_movies_by_genre(genre_id, genre_name, page):
  url = f"{BASE_URL}/discover/movie?api_key={API_KEY}&with_genres={genre_id}&page={page}"
  data = get_json(url)

  __previous_pages(page, {
    'action': 'movies_by_genre',
    'genre_id': genre_id,
    'genre_name': genre_name
  })

  for movie in data['results']:
    __list_movie(movie)

  __next_pages(page, data['total_pages'], {
    'action': 'movies_by_genre',
    'genre_id': genre_id,
    'genre_name': genre_name
  })

  xbmcplugin.endOfDirectory(ADDON_HANDLE)


def find_movies():
  keyboard = xbmc.Keyboard('', 'Enter search term')
  keyboard.doModal()
  if keyboard.isConfirmed():
    query = keyboard.getText()
    page = 1
    search_movies(query, page)


def search_movies(query, page):
  url = f"{BASE_URL}/search/movie?api_key={API_KEY}&query={quote(query)}&page={page}"
  data = get_json(url)

  __previous_pages(page, {'action': 'search', 'query': query})

  for movie in data['results']:
    __list_movie(movie)

  __next_pages(page, data['total_pages'], {'action': 'search', 'query': query})

  xbmcplugin.endOfDirectory(ADDON_HANDLE)


def play_movie(movie_id):
  xbmc.log(f"Resolving {movie_id}", level=xbmc.LOGINFO)

  playback_url = None
  error_message = None
  try:
    # playback_url = vidsrc.resolve(movie_id)
    result = requests.get(f"http://192.168.0.145:8080/fetch?movieid={movie_id}")
    data = json.loads(result.text)
    playback_url = data['playlist'] if data['playlist'] else None
  except Exception as e:
    error_message = f"- {e}"

  if playback_url is None:
    show_notification("Error",
                      f"Could not resolve movie {movie_id} {error_message}")
    xbmc.log(f"Could not resolve movie {movie_id}", level=xbmc.LOGINFO)
    return

  xbmc.log(f"Playing vidsrc {playback_url}", level=xbmc.LOGINFO)

  # Create a ListItem for playback
  list_item = xbmcgui.ListItem(path=playback_url)
  xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=True,
                            listitem=list_item)


def __list_movie(movie):
  title = f"{movie['title']} ({movie['release_date'][:4] if 'release_date' in movie and movie['release_date'] else 'N/A'})"
  rating = f"{round(movie['vote_average'], 2)} ({movie['vote_count']})"
  normalized_rating = __normalize_score(movie['popularity'], 1500,
                                        movie['vote_count'],
                                        movie['vote_average'])
  plot = f"{movie['overview']}\n\nRating: {rating}\nNormalized Rating: {normalized_rating}"
  backdrop = movie['backdrop_path'] if 'backdrop_path' in movie and movie[
    'backdrop_path'] else ''
  poster = movie['poster_path'] if 'poster_path' in movie and movie[
    'poster_path'] else ''

  list_item = xbmcgui.ListItem(title)
  list_item.setArt(
      {
        'poster': IMAGE_BASE_URL + (poster if poster else backdrop),
        'banner': IMAGE_BASE_URL + (backdrop if backdrop else poster),
        'thumb': THUMB_BASE_URL + (poster if poster else backdrop),
        'icon': THUMB_BASE_URL + (poster if poster else backdrop)
      }
  )
  list_item.setInfo(type="video", infoLabels={
    'title': title,
    'plot': plot,
    'Rating': str(normalized_rating)
  })
  list_item.setProperty("IsPlayable", 'True')
  url = build_url({'action': 'play_movie', 'id': movie['id']})
  xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, False)


def __normalize_score(popularity, max_popularity, reviews, review_score):
  # popularity decreases in importance is it increases
  pop_factor = math.log(popularity + 50, 10) / math.log(max_popularity + 1, 10)
  # review factor increases drastically as reviews increase
  review_transition_score = 1.2
  review_factor = reviews * review_transition_score / 10
  if reviews > 10:
    review_factor = review_transition_score + ((reviews - 10) * 0.9 / 89)

  # bound to 0-10
  return round(max(0, min(review_score * pop_factor * review_factor, 10)), 2)


def on_action(action, control_id):
  xbmc.log(f"ListItem Action: {action}", level=xbmc.LOGINFO)


def __previous_pages(page, params):
  if page > 1:
    main_url = build_url({})
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, main_url,
                                xbmcgui.ListItem('Back to main page'), True)

    prev_url = build_url(__append_dicts(params, {'page': 1}))
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, prev_url,
                                xbmcgui.ListItem('First'), True)

  if page > 10:
    prev_url = build_url(__append_dicts(params, {'page': page - 10}))
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, prev_url,
                                xbmcgui.ListItem(f'Page {page - 10}'), True)

  if page > 2:
    prev_url = build_url(__append_dicts(params, {'page': page - 1}))
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, prev_url,
                                xbmcgui.ListItem(f'Page {page - 1}'), True)


def __next_pages(page, total_pages, params):
  if page < total_pages:
    next_url = build_url(__append_dicts(params, {'page': page + 1}))
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, next_url,
                                xbmcgui.ListItem(f'Page {page + 1}'), True)

  if page + 2 < total_pages:
    next_url = build_url(__append_dicts(params, {'page': page + 2}))
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, next_url,
                                xbmcgui.ListItem(f'Page {page + 2}'), True)

  if page + 5 < total_pages:
    next_url = build_url(__append_dicts(params, {'page': page + 5}))
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, next_url,
                                xbmcgui.ListItem(f'Page {page + 5}'), True)

  if page + 1 < total_pages:
    next_url = build_url(__append_dicts(params, {'page': total_pages - 1}))
    xbmcplugin.addDirectoryItem(ADDON_HANDLE, next_url,
                                xbmcgui.ListItem('Last'), True)


def __append_dicts(dict1, dict2):
  dict1.update(dict2)
  return dict1


## -----------------------------------

params = parse_qs(sys.argv[2][1:])
action = params.get('action', [None])[0]
page = int(params.get('page', [1])[0])

xbmc.log(f"Action: {action}", level=xbmc.LOGINFO)

if action is None:
  main_menu()
elif action == 'trending':
  list_trending(page)
elif action == 'genres':
  list_genres()
elif action == 'movies_by_genre':
  genre_id = params['genre_id'][0]
  genre_name = params['genre_name'][0]
  list_movies_by_genre(genre_id, genre_name, page)
elif action == 'find':
  find_movies()
elif action == 'search':
  query = params['query'][0]
  search_movies(query, page)
elif action == 'play_movie':
  movie_id = params['id'][0]
  xbmc.log(f"Movie ID: {movie_id}", level=xbmc.LOGINFO)
  play_movie(movie_id)
